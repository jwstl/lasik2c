<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-gb" lang="en-gb" >
<head>
	  <base href="http://lasik2c.com/index.php" />
  <meta http-equiv="content-type" content="text/html; charset=utf-8" />
  <meta name="keywords" content="Lasik San Antonio, Lasik Eye Surgery, Lasik Surgeon, laser vision correction, eye doctor, eye surgeon, cataracts, cataract surgery, Intacs Corneal Implants" />
  <meta name="description" content="Lasik San Antonio  eye surgery Lasik (Laser-Assisted in Situ Keratomileusis), commonly referred to as laser eye surgery, is a type of refractive surgery for the correction of myopia, hyperopia, and astigmatism. The LASIK surgery is performed by an ophthalmologist who uses a laser or microkeratome to reshape the eye's cornea in order to improve visual acuity" />
  <meta name="generator" content="Joomla! - Open Source Content Management" />
  <title>Ultravision Lasik San Antonio</title>
  <link href="http://lasik2c.com/" rel="canonical" />
  <link href="/?format=feed&amp;type=rss" rel="alternate" type="application/rss+xml" title="RSS 2.0" />
  <link href="/?format=feed&amp;type=atom" rel="alternate" type="application/atom+xml" title="Atom 1.0" />
  <link rel="stylesheet" href="/plugins/system/jcemediabox/css/jcemediabox.css?380a314203b6e1c4df5166f3a813030a" type="text/css" />
  <link rel="stylesheet" href="/plugins/system/jcemediabox/themes/light/css/style.css?5b26173937680c0f1ce985cf96253c9e" type="text/css" />
  <link rel="stylesheet" href="/plugins/system/rokbox/assets/styles/rokbox.css" type="text/css" />
  <link rel="stylesheet" href="/libraries/gantry/css/grid-12.css" type="text/css" />
  <link rel="stylesheet" href="/templates/rt_diametric/css-compiled/master.css" type="text/css" />
  <link rel="stylesheet" href="/templates/rt_diametric/css/gantry-core.css" type="text/css" />
  <link rel="stylesheet" href="/templates/rt_diametric/css/joomla-core.css" type="text/css" />
  <link rel="stylesheet" href="/templates/rt_diametric/css/overlays.css" type="text/css" />
  <link rel="stylesheet" href="/templates/rt_diametric/css/body-light.css" type="text/css" />
  <link rel="stylesheet" href="/templates/rt_diametric/css/menu-light.css" type="text/css" />
  <link rel="stylesheet" href="/templates/rt_diametric/css/typography.css" type="text/css" />
  <link rel="stylesheet" href="/templates/rt_diametric/css/extensions.css" type="text/css" />
  <link rel="stylesheet" href="/templates/rt_diametric/css/demo-styles.css" type="text/css" />
  <link rel="stylesheet" href="/templates/rt_diametric/css/template.css" type="text/css" />
  <link rel="stylesheet" href="/templates/rt_diametric/css/owl.carousel.css" type="text/css" />
  <link rel="stylesheet" href="/templates/rt_diametric/css/owl.theme.css" type="text/css" />
  <link rel="stylesheet" href="/templates/rt_diametric/css/fusionmenu.css" type="text/css" />
  <link rel="stylesheet" href="/media/com_acymailing/css/module_default.css" type="text/css" />
  <link rel="stylesheet" href="http://lasik2c.com/modules/mod_bt_googlemaps/tmpl/css/style.css" type="text/css" />
  <link rel="stylesheet" href="/modules/mod_djimageslider/assets/slimbox/css/slimbox.css" type="text/css" />
  <link rel="stylesheet" href="http://lasik2c.com/modules/mod_djimageslider/assets/style.css" type="text/css" />
  <link rel="stylesheet" href="/templates/rt_diametric/roksprocket/layouts/tabs/themes/default/tabs.css" type="text/css" />
  <link rel="stylesheet" href="/modules/mod_news_show_sp2/assets/css/mod_news_show_sp2.css" type="text/css" />
  <link rel="stylesheet" href="http://lasik2c.com/modules/mod_uniteswitcher/tmpl/transparent.css" type="text/css" />
  <link rel="stylesheet" href="/modules/mod_rokajaxsearch/css/rokajaxsearch.css" type="text/css" />
  <link rel="stylesheet" href="/modules/mod_rokajaxsearch/themes/blue/rokajaxsearch-theme.css" type="text/css" />
  <style type="text/css">
#rt-main-container article h2 span, #rt-main-container a, #rt-main-container h1 span, #rt-main-container .module-title .title span,#rt-body-surround .sprocket-lists .sprocket-lists-container li.active .sprocket-lists-title, body #roksearch_results h3, body #roksearch_results a, .item-title, .component-body .thumbnail a {color:#0c5575;}
#rt-navigation, #rt-navigation .rt-menubar ul.menutop li.active {background-color:#073347;}
#rt-main-container .readon span, #rt-main-container .readon .button, #rt-main-container .button, #rt-main-container .btn, .component-content .formelm-buttons button, .component-body #imageForm.form-horizontal button, .component-body #uploadform button {background-color:#073347;}
#rt-body-surround .box1 .module-surround, #rt-body-surround .box4 .module-surround, .rg-grid-view .tag, .rg-list-view .tag, .rg-detail-slicetag .tag, .rg-detail-filetag .tag  {background-color:#0c5575;}
.menutop .rt-arrow-pointer {border-top-color:#073042;}
#rt-main-container.body-overlay-light a:hover, #rt-main-container.body-overlay-light .title a:hover span {color:#052330;}
#rt-main-container.body-overlay-dark a:hover, #rt-main-container.body-overlay-dark .title a:hover span {color:#1387ba;}
#rt-body-surround.body-accentoverlay-dark .box1 a, #rt-body-surround.body-accentoverlay-dark .box1 .title span, #rt-body-surround.body-accentoverlay-dark .box4 a, #rt-body-surround.body-accentoverlay-dark .box4 .title span, #rt-body-surround.body-accentoverlay-dark .box5 .title span {color:#1387ba;}
#rt-body-surround .box4 .title, #rt-body-surround .box1 .title {text-shadow: -1px 1px 0 #0c5575, -3px 3px 0 rgba(0,0,0,0.15);}
#rt-body-surround .box1 a, #rt-body-surround .box1 a, #rt-body-surround .box1 .title span, #rt-body-surround #rt-top .box4 a, #rt-body-surround #rt-header .box4 a, #rt-body-surround .box4 .title span {color:#1387ba;}
#rt-headerblock h1 span, #rt-headerblock .module-title .title span, body #rt-menu ul.menu li a {color:#0c5575;}
#rt-headerblock .readon span, #rt-headerblock .readon .button, #rt-headerblock .button, #rt-headerblock .btn  {background-color:#073347;}
#rt-headerblock,#rt-headerblock .sprocket-features-arrows .prev, #rt-headerblock .sprocket-features-arrows .next, .layout-showcase .sprocket-features-pagination li {background-color:#f0f0f0;}
#rt-headerblock .title, #rt-headerblock .paneltitle, #rt-headerblock .panelsubtitle, #rt-headerblock .sprocket-features-title {text-shadow: -1px 1px 0 #f0f0f0, -3px 3px 0 rgba(0,0,0,0.2);}
#rt-headerblock .box1 .module-surround, #rt-headerblock .box4 .module-surround {background-color:#0c5575;}
#rt-headerblock #rt-top a, #rt-headerblock #rt-header a {color:#0c5575;}
.headerpanel-overlay-light#rt-headerblock #rt-top a:hover, .headerpanel-overlay-light#rt-headerblock #rt-header a:hover {color:#073347;}
.headerpanel-overlay-dark#rt-headerblock #rt-top a:hover, .headerpanel-overlay-dark#rt-headerblock #rt-header a:hover {color:#1177a3;}
#rt-headerblock #rt-top .box1 a, #rt-headerblock #rt-header .box1 a, #rt-headerblock .box1 .title span, #rt-headerblock #rt-top .box4 a, #rt-headerblock #rt-header .box4 a, #rt-headerblock .box4 .title span {color:#1387ba;}
#rt-headerblock .box4 .title, #rt-headerblock .box1 .title {text-shadow: -1px 1px 0 #0c5575, -3px 3px 0 rgba(0,0,0,0.15);}
#rt-feature h1 span, #rt-feature .module-title .title span {color:#394454;}
#rt-feature .readon span, #rt-feature .readon .button, #rt-feature .button, #rt-feature .btn {background-color:#242b36;}
#rt-feature {background-color:#ABB3B6;}
#rt-feature .box1 .module-surround, #rt-feature .box4 .module-surround {background-color:#394454;}
#rt-feature a {color:#394454;}
#rt-feature .title, #rt-feature .paneltitle, #rt-feature .panelsubtitle {text-shadow: -1px 1px 0 #909a9e, -3px 3px 0 rgba(0,0,0,0.2);}
#rt-feature .feature-accentoverlay-dark .box1 a, #rt-feature feature-accentoverlay-dark .box1 .title span, #rt-feature .feature-accentoverlay-dark .box4 a, #rt-feature .feature-accentoverlay-dark .box4 .title span {color:#586982;}
#rt-feature .box1 .title, #rt-feature .box4 .title {text-shadow: -1px 1px 0 #394454, -3px 3px 0 rgba(0,0,0,0.2);}
#rt-feature .box1 a, #rt-feature .box4 a, #rt-feature .box1 .title span, #rt-feature #rt-top .box4 a, #rt-feature #rt-header .box4 a, #rt-feature .box4 .title span {color:#586982;}
#rt-showcase h1 span, #rt-showcase .module-title .title span, #rt-bottom h1 span, #rt-bottom .module-title .title span {color:#0c5575;}
#rt-showcase .readon span, #rt-showcase .readon .button, #rt-showcase .button, #rt-showcase .btn, #rt-bottom .readon span, #rt-bottom .readon .button, #rt-bottom .button, #rt-bottom .btn {background-color:#073347;}
#rt-showcase, #rt-bottom {background-color:#2B333F;}
#rt-showcase .box1 .module-surround, #rt-showcase .box4 .module-surround, #rt-bottom .box1 .module-surround, #rt-bottom .box4 .module-surround, #rt-bottom .bottom-accentoverlay-dark .box1 a, #rt-bottom .bottom-accentoverlay-dark .box4 .title span, #rt-bottom .bottom-accentoverlay-dark .box4 a, #rt-bottom .bottom-accentoverlay-dark .box1 .title span {background-color:#0c5575;}
#rt-showcase .title, #rt-bottom .title, #rt-showcase .paneltitle, #rt-showcase .panelsubtitle, #rt-bottom .paneltitle, #rt-bottom .panelsubtitle {text-shadow: -1px 1px 0 #2B333F, -3px 3px 0 rgba(0,0,0,0.2);}
#rt-showcase a, #rt-bottom a {color:#0c5575;}
#rt-showcase.showcasepanel-overlay-light a:hover, #rt-bottom.showcasepanel-overlay-light a:hover {color:#073347;}
#rt-showcase.showcasepanel-overlay-dark a:hover, #rt-bottom.showcasepanel-overlay-dark a:hover {color:#1177a3;}
#rt-showcase .box1 a, #rt-showcase .box1 .title span, #rt-showcase .box4 a, #rt-showcase .box4 .title span, #rt-bottom .box1 a, #rt-bottom .box1 .title span, #rt-bottom .box4 a, #rt-bottom .box4 .title span {color:#1387ba;}
#rt-showcase .box4 .title, #rt-showcase .box1 .title, #rt-bottom .box4 .title, #rt-bottom .box1 .title {text-shadow: -1px 1px 0 #0c5575, -3px 3px 0 rgba(0,0,0,0.15);}
#rt-footer-surround h1 span, #rt-footer-surround .module-title .title span {color:#2B9DE6;}
#rt-footer-surround .readon span, #rt-footer-surround .readon .button, #rt-footer-surround .button, #rt-footer-surround .btn {background-color:#1782c7;}
#rt-footer-surround {background-color:#1F75AB;}
#rt-footer-surround .box1 .module-surround, #rt-footer-surround .box4 .module-surround {background-color:#2B9DE6;}
#rt-footer-surround.footerpanel-overlay-light .module-title .title span {color:#1a91dd;}
#rt-footer-surround.footerpanel-overlay-dark .module-title .title span {color:#86c7f1;}
#rt-footer-surround a {color:#9dd2f3;}
#rt-footer-surround.footerpanel-overlay-dark a:hover {color:#6fbdee;}
#rt-footer-surround.footerpanel-overlay-light a:hover {color:#1573b0;}
#rt-footer-surround .title, #rt-footer-surround .paneltitle, #rt-footer-surround .panelsubtitle {text-shadow: -1px 1px 0 #1F75AB, -3px 3px 0 rgba(0,0,0,0.15);}
#rt-footer-surround .box1 a, #rt-footer-surround .box1 .title span, #rt-footer-surround .box4 a, #rt-footer-surround .box4 .title span {color:#6fbdee;}
#rt-footer-surround .box4 .title, #rt-footer-surround .box1 .title {text-shadow: -1px 1px 0 #2B9DE6, -3px 3px 0 rgba(0,0,0,0.15);}


		/* Styles for DJ Image Slider with module id 234 */

		#djslider-loader234 {

			margin: 0 auto;

			position: relative;

		}

		#djslider234 {

			margin: 0 auto;

			position: relative;

			height: 200px; 

			width: 410px;

			max-width: 410px;

		}

		#slider-container234 {

			position: absolute;

			overflow:hidden;

			left: 0; 

			top: 0;

			height: 100%;

			width: 100%;

		}

		#djslider234 ul#slider234 {

			margin: 0 !important;

			padding: 0 !important;

			border: 0 !important;

		}

		#djslider234 ul#slider234 li {

			list-style: none outside !important;

			float: left;

			margin: 0 !important;

			border: 0 !important;

			padding: 0 10px 0px 0 !important;

			position: relative;

			height: 200px;

			width: 200px;

			background: none;

			overflow: hidden;

		}

		#slider234 li img {

			width: 100%;

			height: auto;

			border: 0 !important;

			margin: 0 !important;

		}

		#slider234 li a img, #slider234 li a:hover img {

			border: 0 !important;

		}

		

		/* Slide description area */

		#slider234 .slide-desc {

			position: absolute;

			bottom: 0%;

			left: 0%;

			width: 100%;

		}

		#slider234 .slide-desc-in {

			position: relative;

			margin: 0 10px 0px 0 !important;

		}

		#slider234 .slide-desc-bg {

			position:absolute;

			top: 0;

			left: 0;

			width: 100%;

			height: 100%;

		}

		#slider234 .slide-desc-text {

			position: relative;

		}

		#slider234 .slide-desc-text h3 {

			display: block !important;

		}

		

		/* Styles for DJ Image Slider with module id 217 */

		#djslider-loader217 {

			margin: 0 auto;

			position: relative;

		}

		#djslider217 {

			margin: 0 auto;

			position: relative;

			height: 439px; 

			width: 1600px;

			max-width: 1600px;

		}

		#slider-container217 {

			position: absolute;

			overflow:hidden;

			left: 0; 

			top: 0;

			height: 100%;

			width: 100%;

		}

		#djslider217 ul#slider217 {

			margin: 0 !important;

			padding: 0 !important;

			border: 0 !important;

		}

		#djslider217 ul#slider217 li {

			list-style: none outside !important;

			float: left;

			margin: 0 !important;

			border: 0 !important;

			padding: 0 10px 0px 0 !important;

			position: relative;

			height: 439px;

			width: 1600px;

			background: none;

			overflow: hidden;

		}

		#slider217 li img {

			width: 100%;

			height: auto;

			border: 0 !important;

			margin: 0 !important;

		}

		#slider217 li a img, #slider217 li a:hover img {

			border: 0 !important;

		}

		

		/* Navigation buttons */

		#navigation217 {

			/*position: relative;*/

			top: 6.83371298405%; 

			margin: 0 5px;

			text-align: center !important;

		}

		

		#prev217 {

			cursor: pointer;

			display: block;

			position: absolute;

			left: 0;

		}

		#next217 {

			cursor: pointer;

			display: block;

			position: absolute;

			right: 0;

		}

		
  </style>
  <script src="/media/jui/js/jquery.min.js" type="text/javascript"></script>
  <script src="/media/jui/js/jquery-noconflict.js" type="text/javascript"></script>
  <script src="/media/jui/js/jquery-migrate.min.js" type="text/javascript"></script>
  <script src="/media/system/js/caption.js" type="text/javascript"></script>
  <script src="/plugins/system/jcemediabox/js/jcemediabox.js?d95577726527bb372fd7fcb454409743" type="text/javascript"></script>
  <script src="/media/system/js/mootools-core.js" type="text/javascript"></script>
  <script src="/media/system/js/core.js" type="text/javascript"></script>
  <script src="/media/system/js/mootools-more.js" type="text/javascript"></script>
  <script src="/plugins/system/rokbox/assets/js/rokbox.js" type="text/javascript"></script>
  <script src="/libraries/gantry/js/gantry-totop.js" type="text/javascript"></script>
  <script src="/libraries/gantry/js/gantry-smartload.js" type="text/javascript"></script>
  <script src="/libraries/gantry/js/gantry-buildspans.js" type="text/javascript"></script>
  <script src="/libraries/gantry/js/gantry-inputs.js" type="text/javascript"></script>
  <script src="/libraries/gantry/js/browser-engines.js" type="text/javascript"></script>
  <script src="/templates/rt_diametric/js/load-transition.js" type="text/javascript"></script>
  <script src="/templates/rt_diametric/js/owl.carousel.js" type="text/javascript"></script>
  <script src="/modules/mod_roknavmenu/themes/fusion/js/fusion.js" type="text/javascript"></script>
  <script src="/media/com_acymailing/js/acymailing_module.js" type="text/javascript"></script>
  <script src="//maps.google.com/maps/api/js?sensor=true&language=en-GB" type="text/javascript"></script>
  <script src="http://lasik2c.com/modules/mod_bt_googlemaps/tmpl/js/btbase64.min.js" type="text/javascript"></script>
  <script src="http://lasik2c.com/modules/mod_bt_googlemaps/tmpl/js/default.js" type="text/javascript"></script>
  <script src="/modules/mod_djimageslider/assets/slimbox/js/slimbox.js" type="text/javascript"></script>
  <script src="/modules/mod_djimageslider/assets/powertools-1.2.0.js" type="text/javascript"></script>
  <script src="/modules/mod_djimageslider/assets/slider.js" type="text/javascript"></script>
  <script src="/components/com_roksprocket/assets/js/mootools-mobile.js" type="text/javascript"></script>
  <script src="/components/com_roksprocket/assets/js/rokmediaqueries.js" type="text/javascript"></script>
  <script src="/components/com_roksprocket/assets/js/roksprocket.js" type="text/javascript"></script>
  <script src="/components/com_roksprocket/layouts/tabs/themes/default/tabs.js" type="text/javascript"></script>
  <script src="/modules/mod_news_show_sp2/assets/js/nssp2.js" type="text/javascript"></script>
  <script src="/modules/mod_rokajaxsearch/js/rokajaxsearch.js" type="text/javascript"></script>
  <script type="text/javascript">
jQuery(window).on('load',  function() {
				new JCaption('img.caption');
			});JCEMediaBox.init({popup:{width:"",height:"",legacy:0,lightbox:0,shadowbox:0,resize:1,icons:0,overlay:1,overlayopacity:0.8,overlaycolor:"#000000",fadespeed:500,scalespeed:500,hideobjects:0,scrolling:"fixed",close:2,labels:{'close':'Close','next':'Next','previous':'Previous','cancel':'Cancel','numbers':'{$current} of {$total}'},cookie_expiry:"",google_viewer:0,pdfjs:0},tooltip:{className:"tooltip",opacity:0.8,speed:150,position:"br",offsets:{x: 16, y: 16}},base:"/",imgpath:"plugins/system/jcemediabox/img",theme:"light",themecustom:"",themepath:"plugins/system/jcemediabox/themes"});if (typeof RokBoxSettings == 'undefined') RokBoxSettings = {pc: '100'};window.addEvent('domready', function() {new GantrySmartLoad({'offset': {'x': 200, 'y': 200}, 'placeholder': '/templates/rt_diametric/images/blank.gif', 'exclusion': ['']}); });
			window.addEvent('domready', function() {
				var modules = ['rt-block'];
				var header = ['h3','h2:not(.itemTitle)','h1'];
				GantryBuildSpans(modules, header);
			});
		InputsExclusion.push('.content_vote','#rt-popup','#rt-popuplogin','#vmMainPage','#community-wrap')window.addEvent("domready", function(){ if (typeof SmoothScroll != "undefined") new SmoothScroll(); else new Fx.SmoothScroll(); });            window.addEvent('domready', function() {
                new Fusion('ul.menutop', {
                    pill: 0,
                    effect: 'slide and fade',
                    opacity:  1,
                    hideDelay:  500,
                    centered:  0,
                    tweakInitial: {'x': -8, 'y': -6},
                    tweakSubsequent: {'x':  -8, 'y':  -11},
                    tweakSizes: {'width': 18, 'height': 20},
                    menuFx: {duration:  300, transition: Fx.Transitions.Circ.easeOut},
                    pillFx: {duration:  400, transition: Fx.Transitions.Back.easeOut}
                });
            });
            <!--
					var acymailing = Array();
					acymailing['NAMECAPTION'] = 'Name';
					acymailing['NAME_MISSING'] = 'Please enter your name';
					acymailing['EMAILCAPTION'] = 'E-mail';
					acymailing['VALID_EMAIL'] = 'Please enter a valid e-mail address';
					acymailing['ACCEPT_TERMS'] = 'Please check the Terms and Conditions';
					acymailing['CAPTCHA_MISSING'] = 'Please enter the security code displayed in the image';
					acymailing['NO_LIST_SELECTED'] = 'Please select the lists you want to subscribe to';
			//-->(function($){ window.addEvent('domready',function(){this.Slider234 = new DJImageSliderModule({id: '234', slider_type: 0, slide_size: 210, visible_slides: 2, show_buttons: 0, show_arrows: 0, preload: 800},{auto: 1, transition: Fx.Transitions.Expo.easeInOut, duration: 1000, delay: 4000})}); })(document.id);if (typeof RokSprocket == 'undefined') RokSprocket = {};
Object.merge(RokSprocket, {
	SiteURL: 'http://lasik2c.com/',
	CurrentURL: 'http://lasik2c.com/',
	AjaxURL: 'http://lasik2c.com/index.php?option=com_roksprocket&amp;task=ajax&amp;format=raw&amp;ItemId=101'
});
window.addEvent('domready', function(){
		RokSprocket.instances.tabs = new RokSprocket.Tabs();
});
window.addEvent('domready', function(){
	RokSprocket.instances.tabs.attach(195, '{"autoplay":"0","delay":"5"}');
});
window.addEvent('domready', function(){
	RokSprocket.instances.tabs.attach(155, '{"autoplay":"0","delay":"5"}');
});
(function($){ window.addEvent('domready',function(){this.Slider217 = new DJImageSliderModule({id: '217', slider_type: 0, slide_size: 1610, visible_slides: 1, show_buttons: 0, show_arrows: 1, preload: 800},{auto: 1, transition: Fx.Transitions.Expo.easeInOut, duration: 1000, delay: 4000})}); })(document.id);window.addEvent((window.webkit) ? 'load' : 'domready', function() {
				window.rokajaxsearch = new RokAjaxSearch({
					'results': 'Results',
					'close': '',
					'websearch': 0,
					'blogsearch': 0,
					'imagesearch': 0,
					'videosearch': 0,
					'imagesize': 'MEDIUM',
					'safesearch': 'MODERATE',
					'search': 'Search...',
					'readmore': 'Read more...',
					'noresults': 'No results',
					'advsearch': 'Advanced search',
					'page': 'Page',
					'page_of': 'of',
					'searchlink': 'http://lasik2c.com/index.php?option=com_search&amp;view=search&amp;tmpl=component',
					'advsearchlink': 'http://lasik2c.com/index.php?option=com_search&amp;view=search',
					'uribase': 'http://lasik2c.com/',
					'limit': '10',
					'perpage': '3',
					'ordering': 'newest',
					'phrase': 'any',
					'hidedivs': '',
					'includelink': 1,
					'viewall': 'View all results',
					'estimated': 'estimated',
					'showestimated': 1,
					'showpagination': 1,
					'showcategory': 1,
					'showreadmore': 1,
					'showdescription': 1
				});
			});
  </script>
  <link rel="stylesheet" href="/plugins/system/videobox/css/videobox.css" type="text/css" media="screen" />
  <link rel="stylesheet" href="/libraries/videobox/css/videobox.css" type="text/css" media="screen" />
  <link rel="stylesheet" href="/libraries/videobox/css/functions.css" type="text/css" media="screen" />
  <script type="text/javascript" src="/libraries/videobox/js/jquery.min.js"></script><script type="text/javascript">jQuery.noConflict();</script>
  <script type="text/javascript" src="/libraries/videobox/js/videobox.js"></script>
  <script type="text/javascript" src="/libraries/videobox/js/functions.js"></script>
</head>
	<body  class="presets-preset1 logostyle-style2 textshadow-1 font-family-diametric font-size-is-default logo-type-diametric menu-type-fusionmenu inputstyling-enabled-1 typography-style-light col12 option-com-content menu-home apr12-home">
		<div id="rt-page-surround">
			<div id="rt-headerblock" class="headerpanel-overlay-light"><div id="rt-headerblock2" class="headerpanel-pattern-noise"><div id="rt-headerblock3" class="headerpanel-accentoverlay-dark">
				<div id="rt-top-surround" class="nopadding">
															<div id="rt-drawer">
						<div class="rt-container">
														<div class="clear"></div>
						</div>
					</div>
															<div id="rt-top">
						<div class="rt-container">
							<div class="rt-grid-5 rt-alpha">
                    <div class=" contact_top">
                    <div class="rt-block">
            	<div class="module-surround">
										<div class="module-content">
	                	

<div class="custom contact_top"  >
	<div><span class="text-icon phone">+210-308-5550</span> &nbsp; <span class="text-icon email">ultra@lasik2c.com </span></div></div>
						<div class="clear"></div>
					</div>
				</div>
				            </div>
                </div>
			
</div>
<div class="rt-grid-2">
                    <div class=" contact_top">
                    <div class="rt-block">
            	<div class="module-surround">
										<div class="module-content">
	                	

<div class="custom contact_top"  >
	</div>
						<div class="clear"></div>
					</div>
				</div>
				            </div>
                </div>
			
</div>
<div class="rt-grid-5 rt-omega">
                    <div class="  contact_top pull-right">
                    <div class="rt-block">
            	<div class="module-surround">
										<div class="module-content">
	                	
<div class="mod-languages">

	<ul class="list_uniteswitcher language-switcher">	
    <li class="lang-active">
	<a href="#">
        <span>English (USA) </span> 
		<img alt="English (USA)" src="http://lasik2c.fireflycollab.com/modules/mod_uniteswitcher/tmpl/images/default/us.gif"/> 
	</a>
	</li>
				<li class="">
			<a href="/">
                <span>Spanish (ES) </span> 
				<img src="http://lasik2c.com/modules/mod_uniteswitcher/tmpl/images/default/es.gif" alt="Spanish (ES)"/> 
			</a>
			</li>
					<li class="">
			<a href="/">
                <span>English (USA) </span> 
				<img src="http://lasik2c.com/modules/mod_uniteswitcher/tmpl/images/default/us.gif" alt="English (USA)"/> 
			</a>
			</li>
			
	</ul>

</div>
						<div class="clear"></div>
					</div>
				</div>
				            </div>
                </div>
			                <div class=" contact_top pull-right">
                    <div class="rt-block">
            	<div class="module-surround">
										<div class="module-content">
	                	<style>
#roksearch_search_str::-moz-placeholder,#roksearch_search_str::-webkit-placeholder{color: #0C5575;}
</style>
<form name="rokajaxsearch" id="rokajaxsearch" class="blue" action="http://lasik2c.com/" method="get">
<div class="rokajaxsearch  contact_top pull-right">
	<div class="roksearch-wrapper">
		<input id="roksearch_search_str" name="searchword" type="text" class="inputbox roksearch_search_str" placeholder="Search..." />
	</div>
	<input type="hidden" name="searchphrase" value="any"/>
	<input type="hidden" name="limit" value="20" />
	<input type="hidden" name="ordering" value="newest" />
	<input type="hidden" name="view" value="search" />
	<input type="hidden" name="option" value="com_search" />

	
	<div id="roksearch_results"></div>
</div>
<div id="rokajaxsearch_tmp" style="visibility:hidden;display:none;"></div>
</form>
						<div class="clear"></div>
					</div>
				</div>
				            </div>
                </div>
			
</div>
							<div class="clear"></div>
						</div>
					</div>
									</div>
								<div id="rt-navigation" class="menu-overlay-light"><div id="rt-navigation2"><div id="rt-navigation3" >
					<div class="rt-container">
						<div class="rt-grid-12 rt-alpha rt-omega">
    	<div class="rt-block menu-block">
		<div class="rt-fusionmenu">
<div class="nopill">
<div class="rt-menubar">
    <ul class="menutop level1 "  style="margin-left: 48px;">
                        <li class="item101 active root" >
                        <span class="rt-arrow-pointer"></span>
                                    	                <a class="orphan item bullet active-to-top" href="/"  >
                                            <span>
                                        <span>
                                        Home                                                            </span>
                                            </span>
                                    </a>
            
                    </li>
                                <li class="item198 parent root" >
                        <span class="rt-arrow-pointer"></span>
                                        <span class="daddy item bullet nolink">
                                            <span>
                                        <span>
                                            Practice                                                            <span class="daddyicon"></span>
                                        </span>
                                            </span>
                                    </span>
            
                                                <div class="fusion-submenu-wrapper level2  " style="width:250pxpx;">
                        
                        <ul class="level2" style="width:250px;">
                                                                                                        <li class="item199" >
                                    	                <a class="orphan item bullet" href="/practice/meet-the-doctors"  >
                                        <span>
                                        Meet The Doctors                                                            </span>
                                    </a>
            
                    </li>
                                                                                                                                                <li class="item200" >
                                    	                <a class="orphan item bullet" href="/practice/co-managing-optometrists"  >
                                        <span>
                                        Co-managing Optometrists                                                            </span>
                                    </a>
            
                    </li>
                                                                                                                                                <li class="item201" >
                                    	                <a class="orphan item bullet" href="/practice/the-ultravision-lifetime-pledge"  >
                                        <span>
                                        The UltraVision Lifetime Pledge                                                            </span>
                                    </a>
            
                    </li>
                                                                                                                                                <li class="item202" >
                                    	                <a class="orphan item bullet" href="/practice/our-locations"  >
                                        <span>
                                        Our locations                                                            </span>
                                    </a>
            
                    </li>
                                                                                                                                                <li class="item203" >
                                    	                <a class="orphan item bullet" href="/practice/photos"  >
                                        <span>
                                        Photos                                                            </span>
                                    </a>
            
                    </li>
                                                                                                                                                <li class="item204" >
                                    	                <a class="orphan item bullet" href="/practice/clients"  >
                                        <span>
                                        Clients                                                            </span>
                                    </a>
            
                    </li>
                                                                                                                                                <li class="item205" >
                                    	                <a class="orphan item bullet" href="/practice/career-opportunities"  >
                                        <span>
                                        Career Opportunities                                                            </span>
                                    </a>
            
                    </li>
                                                                                                                                                <li class="item206" >
                                    	                <a class="orphan item bullet" href="/practice/blog"  >
                                        <span>
                                        Blog                                                            </span>
                                    </a>
            
                    </li>
                                                                                            </ul>

                                                <div class="drop-bot"></div>
                    </div>
                                    </li>
                                <li class="item207 parent root" >
                        <span class="rt-arrow-pointer"></span>
                                        <span class="daddy item bullet subtext nolink">
                                            <span>
                                        <span>
                                            Procedures                                        <em>and Services</em>
                                                            <span class="daddyicon"></span>
                                        </span>
                                            </span>
                                    </span>
            
                                                <div class="fusion-submenu-wrapper level2  " style="width:180px;">
                        
                        <ul class="level2" style="width:180px;">
                                                                                                        <li class="item208" >
                                    	                <a class="orphan item bullet" href="/procedures/ophthalmology"  >
                                        <span>
                                        Ophthalmology                                                            </span>
                                    </a>
            
                    </li>
                                                                                                                                                <li class="item209" >
                                    	                <a class="orphan item bullet subtext" href="/procedures/keratoconus"  >
                                        <span>
                                        Keratoconus                                        <em>Intacs</em>
                                                            </span>
                                    </a>
            
                    </li>
                                                                                                                                                <li class="item210" >
                                    	                <a class="orphan item bullet" href="/procedures/ultraoptik"  >
                                        <span>
                                        Ultraoptik                                                            </span>
                                    </a>
            
                    </li>
                                                                                                                                                <li class="item266" >
                                    	                <a class="orphan item bullet subtext" href="/procedures/intralase-technology"  >
                                        <span>
                                        Intralase                                         <em>Technology</em>
                                                            </span>
                                    </a>
            
                    </li>
                                                                                            </ul>

                                                <div class="drop-bot"></div>
                    </div>
                                    </li>
                                <li class="item211 parent root" >
                        <span class="rt-arrow-pointer"></span>
                                    	                <a class="daddy item bullet" href="/lasik"  >
                                            <span>
                                        <span>
                                        LASIK                                                            <span class="daddyicon"></span>
                                        </span>
                                            </span>
                                    </a>
            
                                                <div class="fusion-submenu-wrapper level2  " style="width:250pxpx;">
                        
                        <ul class="level2" style="width:250px;">
                                                                                                        <li class="item212" >
                                    	                <a class="orphan item bullet" href="/lasik/am-i-a-candidate"  >
                                        <span>
                                        Am I A Candidate?                                                            </span>
                                    </a>
            
                    </li>
                                                                                                                                                <li class="item213" >
                                    	                <a class="orphan item bullet subtext" href="/lasik/zyoptix"  >
                                        <span>
                                        Zyoptix™                                        <em>What You Should Expect</em>
                                                            </span>
                                    </a>
            
                    </li>
                                                                                                                                                <li class="item214" >
                                    	                <a class="orphan item bullet subtext" href="/lasik/intralase"  >
                                        <span>
                                        IntraLase®                                        <em>By Ultravision</em>
                                                            </span>
                                    </a>
            
                    </li>
                                                                                                                                                <li class="item215" >
                                    	                <a class="orphan item bullet" href="/lasik/wavefront-comparison-chart"  >
                                        <span>
                                        Wavefront Comparison Chart                                                            </span>
                                    </a>
            
                    </li>
                                                                                                                                                <li class="item216" >
                                    	                <a class="orphan item bullet subtext" href="/lasik/the-bausch-lomb-laser"  >
                                        <span>
                                        The Bausch &amp; Lomb Laser                                        <em>Used For Zyoptix™</em>
                                                            </span>
                                    </a>
            
                    </li>
                                                                                                                                                <li class="item217" >
                                    	                <a class="orphan item bullet subtext" href="/lasik/frequently-asked-questions-about-zyoptix"  >
                                        <span>
                                        Frequently Asked                                        <em>Questions About Zyoptix™</em>
                                                            </span>
                                    </a>
            
                    </li>
                                                                                                                                                <li class="item218" >
                                    	                <a class="orphan item bullet" href="/lasik/lasik-alternatives"  >
                                        <span>
                                        Lasik Alternatives                                                            </span>
                                    </a>
            
                    </li>
                                                                                            </ul>

                                                <div class="drop-bot"></div>
                    </div>
                                    </li>
                        
	   <li class="item179 root menu-module" >
		       <div class="fusion-module ">
		        

<div class="custom"  >
	<a href="/index.php" class="logo-module"></a></div>
    </div>
		   </li>
                                <li class="item219 root" >
                        <span class="rt-arrow-pointer"></span>
                                    	                <a class="orphan item bullet subtext" href="/testimonials"  >
                                            <span>
                                        <span>
                                        Testimonials                                        <em>Videos</em>
                                                            </span>
                                            </span>
                                    </a>
            
                    </li>
                                <li class="item220 root" >
                        <span class="rt-arrow-pointer"></span>
                                    	                <a class="orphan item bullet subtext" href="/payments"  >
                                            <span>
                                        <span>
                                        Payments                                        <em>Options</em>
                                                            </span>
                                            </span>
                                    </a>
            
                    </li>
                                <li class="item221 root" >
                        <span class="rt-arrow-pointer"></span>
                                    	                <a class="orphan item bullet" href="/contact-us"  >
                                            <span>
                                        <span>
                                        Contact Us                                                            </span>
                                            </span>
                                    </a>
            
                    </li>
                    </ul>
</div>
<div class="clear"></div>
</div>
</div>		<div class="clear"></div>
	</div>
	
</div>
						<div class="clear"></div>
					</div>
				</div></div></div>
												<div id="rt-header">
					<div class="rt-container" >
						<div class="rt-grid-12 rt-alpha rt-omega">
                        <div class="rt-block">
            	<div class="module-surround">
										<div class="module-content">
	                	
<div style="border: 0px !important;">

<div id="djslider-loader217" class="djslider-loader">

    <div id="djslider217" class="djslider">

        <div id="slider-container217" class="slider-container">

        	<ul id="slider217">

          		
          			<li>

          				
	            			
								<img src="/images/slider/banner1.jpg" alt="banner1.jpg" />

							
						
												

						

					</li>

                
          			<li>

          				
	            			
								<img src="/images/slider/banner4.jpg" alt="banner4.jpg" />

							
						
												

						

					</li>

                
          			<li>

          				
	            			
								<img src="/images/slider/sea.png" alt="sea.png" />

							
						
												

						

					</li>

                
          			<li>

          				
	            			
								<img src="/images/slider/tomy_starck_02.png" alt="tomy_starck_02.png" />

							
						
												

						

					</li>

                
        	</ul>

        </div>

        
        <div id="navigation217" class="navigation-container_">

        	
            <!--  
        	<img id="prev217" class="prev-button" src="http://lasik2c.com//modules/mod_djimageslider/assets/prev.png" alt="Previous" />
    
			<img id="next217" class="next-button" src="http://lasik2c.com//modules/mod_djimageslider/assets/next.png" alt="Next" />-->
            
            <div class="sprocket-features-arrows">
        		<span id="next217"  class="next-button arrow next"><span></span></span>
        		<span id="prev217" class="prev-button arrow prev"><span></span></span>
        	</div>
            
            

			
			
        </div>

        
        
    </div>

</div>

</div>

<div style="clear: both"></div>						<div class="clear"></div>
					</div>
				</div>
				            </div>
        	
</div>
						<div class="clear"></div>
					</div>
				</div>
							</div></div></div>
            
            
                
            
			<div id="rt-transition" class="rt-hidden">
               
                
												<div id="rt-feature" class="featurepanel-overlay-light"><div id="rt-feature2"><div id="rt-feature3" class="featurepanel-accentoverlay-dark"><div id="rt-feature4" class="featurepanel-pattern-textile">
					<div class="rt-container">
						<div class="rt-grid-8 rt-alpha">
                    <div class="nomarginbottom nopaddingbottom nomargintop nopaddingtop intro">
                    <div class="rt-block">
            	<div class="module-surround">
										<div class="module-content">
	                	

<div class="customnomarginbottom nopaddingbottom nomargintop nopaddingtop intro"  >
	<h1 style="color: #fff;">Ultravision Tomy Starck MD</h1>
<p>UltraVision makes a commitment to stand behind the results of a patient's distance vision because we confide in Dr. Tomy Starck who's LASIK experience spans for more than a decade. Together with the latest and innovative technology, this winning combination offers results that are backed up by our Lifetime Pledge program.</p>
<p>The Lifetime Pledge is Ultravision's commitment that if an enhancement is needed to maintain the results of a patient's distance vision, the patients who qualify will receive the enhancement at no additional cost.</p></div>
						<div class="clear"></div>
					</div>
				</div>
				            </div>
                </div>
			
</div>
<div class="rt-grid-4 rt-omega">
                    <div class="nomargintop nopaddingtop">
                    <div class="rt-block">
            	<div class="module-surround">
										<div class="module-title">
												<h2 class="title">Latest News</h2>
											</div>
	                					<div class="module-content">
	                	 <div data-tabs="155">
	<div class="sprocket-tabs layout-top animation-slideandfade">
				<div class="sprocket-tabs-nav-container">
			<ul class="sprocket-tabs-nav">
								<li data-tabs-navigation><span class="sprocket-tabs-inner">
										<span class="sprocket-tabs-text">
						News					</span>
				</span></li>
							</ul>
		</div>
				<div class="sprocket-tabs-panels">
			<div class="sprocket-tabs-panel" data-tabs-panel>
	<div class="rt-floatleft"></div>
<!--
<p style="clear: both;"><a href="#"><img class="pull-left" src="/images/news/news1.png" alt="" /></a> <strong>We've partnered with VSP insurance.</strong><br /> Patient donate glasses and we then send back to VSP and they donate to developing countries that need glasses.</p>
<p style="clear: both;"><a href="#"><img class="pull-left" src="/images/news/news2.png" alt="" /></a> <strong>Cataract Surgery By Dr. Tomy Starck In San Antonio, Kens 5 InterviewCataract Surgery By Dr. Tomy Starck In San Antonio, Kens 5 Interview - 2012 </strong></p>

<p class="nomarginbottom" style="clear: both;"><a href="#"><img class="pull-left" src="/images/news/news1.png" alt="" /></a> Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>-->
<p>		<div class="moduletable">
					<div id="ns2-219" class="nssp2 ns2-219">
	<div class="ns2-wrap">
					<div class="ns2-art-wrap  nssp2-animation nssp2-default ">			
				<div class="ns2-art-pages">
									<div class="ns2-page">
						<div class="ns2-page-inner">
													<div class="ns2-row ns2-first ns2-odd">
								<div class="ns2-row-inner">
																										<div class="ns2-column flt-left col-1">
										<div style="padding:3px 3px 3px 3px">
											<div class="ns2-inner">
																								
											
																																							<a href="/18-latest-news/87-we-ve-partnered-with-vsp-insurance">
														
														<img class="ns2-image" style="float:left;margin:0 0 0 0" src="/cache/mod_news_show_sp2/nssp2_thumbs/219/news1.png" alt="We've partnered with VSP insurance." title="We've partnered with VSP insurance." />
															
														</a>
																
																								
												
																									<h4 class="ns2-title">
																													<a href="/18-latest-news/87-we-ve-partnered-with-vsp-insurance">
															
															We've partnered with VSP insurance.																													</a>
															
													</h4>
																								
													
															
												
												
																									<p class="ns2-introtext">Patient donate glasses and we then send back to VSP...</p>								
																								
												<div class="ns2-social">
																									</div>
												
																								
																				
												
																									<div class="ns2-links">
																					
														
																													<a class="ns2-readmore" href="/18-latest-news/87-we-ve-partnered-with-vsp-insurance"><span>Read More...</span></a>
																											</div>
																								<div style="clear:both"></div>
												
											</div>
										</div>
									</div>
																									<div style="clear:both"></div>
							</div>
							<div style="clear:both"></div>
							</div>
													<div class="ns2-row  ns2-even">
								<div class="ns2-row-inner">
																										<div class="ns2-column flt-left col-1">
										<div style="padding:3px 3px 3px 3px">
											<div class="ns2-inner">
																								
											
																																							<a href="/18-latest-news/84-corneal-transplant-patient-thanks-ultravision">
														
														<img class="ns2-image" style="float:left;margin:0 0 0 0" src="/cache/mod_news_show_sp2/nssp2_thumbs/219/corneal_transplant_patient.jpg" alt="Corneal Transplant Patient Thanks UltraVision" title="Corneal Transplant Patient Thanks UltraVision" />
															
														</a>
																
																								
												
																									<h4 class="ns2-title">
																													<a href="/18-latest-news/84-corneal-transplant-patient-thanks-ultravision">
															
															Corneal Transplant Patient Thanks UltraVision																													</a>
															
													</h4>
																								
													
															
												
												
																									<p class="ns2-introtext">Corneal Transplant Patient - My mom thinks the world of...</p>								
																								
												<div class="ns2-social">
																									</div>
												
																								
																				
												
																									<div class="ns2-links">
																					
														
																													<a class="ns2-readmore" href="/18-latest-news/84-corneal-transplant-patient-thanks-ultravision"><span>Read More...</span></a>
																											</div>
																								<div style="clear:both"></div>
												
											</div>
										</div>
									</div>
																									<div style="clear:both"></div>
							</div>
							<div style="clear:both"></div>
							</div>
												<div style="clear:both"></div>
						</div><!--end ns2-page-inner-->
					</div>
									<div class="ns2-page">
						<div class="ns2-page-inner">
													<div class="ns2-row ns2-first ns2-odd">
								<div class="ns2-row-inner">
																										<div class="ns2-column flt-left col-1">
										<div style="padding:3px 3px 3px 3px">
											<div class="ns2-inner">
																								
											
																																							<a href="/18-latest-news/83-cataract-surgery-by-dr-tomy-starck-in-san-antonio-kens-5-interviewcataract-surgery-by-dr-tomy-starck-in-san-antonio-kens-5-interview-2012">
														
														<img class="ns2-image" style="float:left;margin:0 0 0 0" src="/cache/mod_news_show_sp2/nssp2_thumbs/219/news2.png" alt="Cataract Surgery By Dr. Tomy Starck In San Antonio, Kens 5 InterviewCataract Surgery By Dr. Tomy Starck In San Antonio, Kens 5 Interview - 2012" title="Cataract Surgery By Dr. Tomy Starck In San Antonio, Kens 5 InterviewCataract Surgery By Dr. Tomy Starck In San Antonio, Kens 5 Interview - 2012" />
															
														</a>
																
																								
												
																									<h4 class="ns2-title">
																													<a href="/18-latest-news/83-cataract-surgery-by-dr-tomy-starck-in-san-antonio-kens-5-interviewcataract-surgery-by-dr-tomy-starck-in-san-antonio-kens-5-interview-2012">
															
															Cataract Surgery By Dr. Tomy...																													</a>
															
													</h4>
																								
													
															
												
												
																									<p class="ns2-introtext">In this Video you can see the procedure of an...</p>								
																								
												<div class="ns2-social">
																									</div>
												
																								
																				
												
																									<div class="ns2-links">
																					
														
																													<a class="ns2-readmore" href="/18-latest-news/83-cataract-surgery-by-dr-tomy-starck-in-san-antonio-kens-5-interviewcataract-surgery-by-dr-tomy-starck-in-san-antonio-kens-5-interview-2012"><span>Read More...</span></a>
																											</div>
																								<div style="clear:both"></div>
												
											</div>
										</div>
									</div>
																									<div style="clear:both"></div>
							</div>
							<div style="clear:both"></div>
							</div>
													<div class="ns2-row  ns2-even">
								<div class="ns2-row-inner">
																																	<div style="clear:both"></div>
							</div>
							<div style="clear:both"></div>
							</div>
												<div style="clear:both"></div>
						</div><!--end ns2-page-inner-->
					</div>
								</div>
				
				
									<div style="clear:both"></div>
					<div class="ns2-art-controllers">
																			
												<div style="clear:both"></div>
					</div>
								<div style="clear:both"></div>
			</div>
				<!--End article layout-->
		
		<!--Links Layout-->
				<!--End Links Layout-->
		<div style="clear:both"></div>
	</div>
</div>

<script type="text/javascript">
//<![CDATA[
window.addEvent('load', function() {
	new nssp2({
		container: document.getElement('#ns2-219 .ns2-art-pages'),
		interval: 5000,
		activator: "click",
		transition: "cover-horizontal-push",	
		fxOptions: {
			duration:  300, 
			transition: Fx.Transitions.linear		},
		buttons: {
								}
				,autoPlay: 1	});
});

//]]>
</script>		</div>
	</p>	</div>
		</div>
			</div>
</div>
						<div class="clear"></div>
					</div>
				</div>
				            </div>
                </div>
			
</div>
						<div class="clear"></div>
					</div>
				</div></div></div></div>
								<div id="rt-main-container" class="body-overlay-light">
					<div id="rt-body-surround" class="body-accentoverlay-dark">
						<div class="rt-container">
																																		              
<div id="rt-main" class="mb12">
	<div class="rt-container">
		<div class="rt-grid-12">
			<div id="rt-main-column">
								<div id="rt-content-top">
					<div class="rt-grid-12 rt-alpha rt-omega">
                    <div class=" feature_div">
                    <div class="rt-block">
            	<div class="module-surround">
										<div class="module-content">
	                	

<div class="custom feature_div"  >
	<div>
<div class="rt-demo-grid-3"><a href="/lasik"><img src="/images/features/1.png" alt="" /></a>
<p class="feature_title"><a href="/lasik">LASIK Eye Surgery</a></p>
</div>
<div class="rt-demo-grid-3"><a href="/procedures/ophthalmology"><img src="/images/features/4.png" alt="" /></a>
<p class="feature_title"><a href="/procedures/ophthalmology">Cataract Surgery</a></p>
</div>
<div class="rt-demo-grid-3"><a href="/procedures/ophthalmology"><img src="/images/features/3.png" alt="" /></a>
<p class="feature_title"><a href="/procedures/ophthalmology">Cornea</a></p>
</div>
<div class="rt-demo-grid-3"><a href="#"><img src="/images/features/2.png" alt="" /></a>
<p class="feature_title"><a href="#">Glaucoma</a></p>
</div>
</div></div>
						<div class="clear"></div>
					</div>
				</div>
				            </div>
                </div>
			
</div>
					<div class="clear"></div>
				</div>
												<div class="rt-block component-block">
					<div id="rt-mainbody">
						<div class="component-content rt-joomla">
							
<section class="blog-featuredapr12-home" itemscope itemtype="http://schema.org/Blog">
	<h1>
	Ultravision Lasik San Antonio	</h1>


</section>



						</div>
					</div>
					<div class="clear"></div>
				</div>
											</div>
		</div>
				<div class="clear"></div>
	</div>
</div>
																											</div>
					</div>
				</div>
							</div>
						<div id="rt-bottom" class="showcasepanel-overlay-dark">
                <div id="rt-bottom2" class="showcasepanel-pattern-denim">
                <div id="rt-bottom3" class="rippedpaper stylelight showcasepanel-accentoverlay-dark">
                <div id="rt-bottom4">
				<div class="rt-container">
					<div class="rt-grid-7 rt-alpha">
                    <div class=" testi">
                    <div class="rt-block">
            	<div class="module-surround">
										<div class="module-content">
	                	<div data-tabs="195">
	<div class="sprocket-tabs layout-top animation-slideandfade">
				<div class="sprocket-tabs-nav-container">
			<ul class="sprocket-tabs-nav">
								<li data-tabs-navigation><span class="sprocket-tabs-inner">
										<span class="sprocket-tabs-text">
						Testimonials					</span>
				</span></li>
								<li data-tabs-navigation><span class="sprocket-tabs-inner">
										<span class="sprocket-tabs-text">
						Payment Options					</span>
				</span></li>
								<li data-tabs-navigation><span class="sprocket-tabs-inner">
										<span class="sprocket-tabs-text">
						New Patient Form					</span>
				</span></li>
							</ul>
		</div>
				<div class="sprocket-tabs-panels">
			<div class="sprocket-tabs-panel" data-tabs-panel>
	
<div style="border: 0px !important;">

<div id="djslider-loader234" class="djslider-loader">

    <div id="djslider234" class="djslider">

        <div id="slider-container234" class="slider-container">

        	<ul id="slider234">

          		
          			<li>

          				
	            			
								<a  class="jcebox" href="https://www.youtube.com/watch?v=uCjuTwQp1RA" target="_self">

							
								<img src="/images/spsimpleportfolio/dr-john-day-testimonial/Dr_John_Day_600x400.jpg" alt="Dr. John Day Testimonial " />

							
								</a>

							
						
						
						<!-- Slide description area: START -->

						<div class="slide-desc">

						  <div class="slide-desc-in">	

							<div class="slide-desc-bg"></div>

							<div class="slide-desc-text">

							
								<div class="slide-title">

									
										Dr. John Day Testimonial 
									
								</div>

							
							

							
							

							
							<div style="clear: both"></div>

							</div>

						  </div>

						</div>

						<!-- Slide description area: END -->

												

						

					</li>

                
          			<li>

          				
	            			
								<a  class="jcebox" href="https://www.youtube.com/watch?v=NwxpHFudFTE" target="_self">

							
								<img src="/images/spsimpleportfolio/dr-chu-testimonial/Dr_Chu_600x400.jpg" alt="Dr. Chu Testimonial" />

							
								</a>

							
						
						
						<!-- Slide description area: START -->

						<div class="slide-desc">

						  <div class="slide-desc-in">	

							<div class="slide-desc-bg"></div>

							<div class="slide-desc-text">

							
								<div class="slide-title">

									
										Dr. Chu Testimonial
									
								</div>

							
							

							
							

							
							<div style="clear: both"></div>

							</div>

						  </div>

						</div>

						<!-- Slide description area: END -->

												

						

					</li>

                
          			<li>

          				
	            			
								<a  class="jcebox" href="https://www.youtube.com/watch?v=vQYl9KKpLYs" target="_self">

							
								<img src="/images/spsimpleportfolio/dr-chu-dr-patel/Dr_Chu_Dr_Patel_600x400.jpg" alt="Dr. Chu & Dr. Patel" />

							
								</a>

							
						
						
						<!-- Slide description area: START -->

						<div class="slide-desc">

						  <div class="slide-desc-in">	

							<div class="slide-desc-bg"></div>

							<div class="slide-desc-text">

							
								<div class="slide-title">

									
										Dr. Chu & Dr. Patel
									
								</div>

							
							

							
							

							
							<div style="clear: both"></div>

							</div>

						  </div>

						</div>

						<!-- Slide description area: END -->

												

						

					</li>

                
          			<li>

          				
	            			
								<a  class="jcebox" href="https://www.youtube.com/watch?v=b-6yZFNu3po" target="_self">

							
								<img src="/images/spsimpleportfolio/dr-michelle-cantu-testimonial/Dr_Michelle_Cantu_600x400.jpg" alt="Dr. Michelle Cantu Testimonial" />

							
								</a>

							
						
						
						<!-- Slide description area: START -->

						<div class="slide-desc">

						  <div class="slide-desc-in">	

							<div class="slide-desc-bg"></div>

							<div class="slide-desc-text">

							
								<div class="slide-title">

									
										Dr. Michelle Cantu Testimonial
									
								</div>

							
							

							
							

							
							<div style="clear: both"></div>

							</div>

						  </div>

						</div>

						<!-- Slide description area: END -->

												

						

					</li>

                
        	</ul>

        </div>

        
        
    </div>

</div>

</div>

<div style="clear: both"></div>	</div>
<div class="sprocket-tabs-panel" data-tabs-panel>
	<div><a target="_blank" href="https://www.carecredit.com/apply/confirm.html?light=1&encm=XD0AOVU3VTBSbg1pW29ZMFZsVDYEZ1RjBGACNVU9AzM="> <img width="148" height="45" alt="logo-care-credit" src="/images/payment_options/logo-care-credit.png"/></a><a target="_blank" href="http://www.carecredit.com/payment_calculator/template.html?amount=$&ss=http://carecredit.com/payment_calculator/template.css&ASPS=0&keys=&x=28&y=16"><img width="162" height="45" alt="logo-care-credit-calculator" src="/images/payment_options/logo-care-credit-calculator.png"/><br/><br/></a></div>	</div>
<div class="sprocket-tabs-panel" data-tabs-panel>
	<div style="text-align: justify;"><p><a target="_blank" href="/images/Forms/cornea_packet_2014.pdf"><strong><span style="font-size: 12pt;">Cornea Patient Packet</span></strong>&nbsp;</a></p><p><span style="font-size: 12pt;"><strong><a target="_blank" href="/images/Forms/lasik_patient_packet.doc">Lasik Patient Packet</a>&nbsp;</strong></span></p></div>	</div>
		</div>
			</div>
</div>
						<div class="clear"></div>
					</div>
				</div>
				            </div>
                </div>
			
</div>
<div class="rt-grid-5 rt-omega">
                        <div class="rt-block">
            	<div class="module-surround">
										<div class="module-title">
												<h2 class="title">Ultravision Video</h2>
											</div>
	                					<div class="module-content">
	                		<script type="text/javascript">
		jQuery(function($) {
			$('.sp_simple_youtube_responsive').each(function(){
				var $that = $(this);
				$('#sp-simple-youtube196').css({
					'width': $(this).width(),
					'height': ( $(this).data('height')*$(this).width() ) / $(this).data('width')
				});

				$(window).resize(function(){
					$('#sp-simple-youtube196').css({
						'width': $that.width(),
						'height': ( $that.data('height')*$that.width() ) / $that.data('width')
					});
				});
			});
		});
	</script>
	
	<div class="sp_simple_youtube sp_simple_youtube_responsive" data-width="300" data-height="200">
					<iframe title="Simple youtube module by JoomShaper.com" id="sp-simple-youtube196" src="http://www.youtube.com/embed/EEFl4SBZ_6c?wmode=transparent" frameborder="0"></iframe>
			</div>

						<div class="clear"></div>
					</div>
				</div>
				            </div>
        	
</div>
                    <div class="clear"></div>
                    
				</div>
                <div class="rt-container" style="padding: 0px;">
                				<div id="rt-high">
					<div class="rt-grid-3 rt-alpha">
                        <div class="rt-block">
            	<div class="module-surround">
										<div class="module-content">
	                	

<div class="custom"  >
	<p><a href="/e-scheduler"><img src="/images/scheduler.png" alt="" /></a></p></div>
						<div class="clear"></div>
					</div>
				</div>
				            </div>
        	
</div>
<div class="rt-grid-3">
                        <div class="rt-block">
            	<div class="module-surround">
										<div class="module-content">
	                	

<div class="custom"  >
	<p><a href="https://www.nextmd.com/ud2/Login/Login.aspx"><img src="/images/next.png" alt="" /></a></p></div>
						<div class="clear"></div>
					</div>
				</div>
				            </div>
        	
</div>
<div class="rt-grid-3">
                    <div class=" hide">
                    <div class="rt-block">
            	<div class="module-surround">
										<div class="module-content">
	                	

<div class="custom hide"  >
	<p><a href="/e-scheduler"><img src="/images/scheduler.png" alt="" /></a></p></div>
						<div class="clear"></div>
					</div>
				</div>
				            </div>
                </div>
			
</div>
<div class="rt-grid-3 rt-omega">
                    <div class="  hide">
                    <div class="rt-block">
            	<div class="module-surround">
										<div class="module-content">
	                	

<div class="custom  hide"  >
	<p><a href="https://www.nextmd.com/ud2/Login/Login.aspx"><img src="/images/next.png" alt="" /></a></p></div>
						<div class="clear"></div>
					</div>
				</div>
				            </div>
                </div>
			
</div>
					<div class="clear"></div>
				</div>
				                </div>
			</div></div></div></div>
									<div id="rt-footer-surround" class="footerpanel-overlay-dark"><div id="rt-footer-surround2" class="footerpanel-pattern-leather"><div id="rt-footer-surround3" class="footerpanel-accentoverlay-dark">
								<div id="rt-footer"><div id="rt-footer2">
					<div class="rt-container">
						<div class="rt-grid-4 rt-alpha">
                    <div class="nomargintop nomarginbottom nopaddingbottom">
                    <div class="rt-block">
            	<div class="module-surround">
										<div class="module-title">
												<h2 class="title">What is the UltraVision Lifetime Pledge?</h2>
											</div>
	                					<div class="module-content">
	                	

<div class="customnomargintop nomarginbottom nopaddingbottom"  >
	<!--<p>All demo content is for <strong>sample</strong> purposes only, intended to represent a live site. All content images are licensed from <a href="http://www.shutterstock.com/" target="_blank">shutterstock.com</a> for exclusive use on this demo only.</p>
<p>Note: <strong>RokSprocket</strong> is only available for <strong>Joomla 2.5.x</strong>. Those functions will be covered in 1.5.x by <em>RokNewsPager</em>, <em>RokNewsFlash</em>, <em>RokStories</em> and <em>RokTabs</em>. RokSprocket is a free extension, <a href="http://www.rockettheme.com/extensions-downloads/free/2841-roksprocket">available now</a>.</p>-->
<p>UltraVision makes a commitment to stand behind the results of a patient's distance vision because we confide in Dr. Tomy Starck who's LASIK experience spans for more than a decade. Together with the latest and innovative technology, this winning combination offers results that are backed up by our Lifetime Pledge program.</p></div>
						<div class="clear"></div>
					</div>
				</div>
				            </div>
                </div>
			
</div>
<div class="rt-grid-4">
                        <div class="rt-block">
            	<div class="module-surround">
										<div class="module-title">
												<h2 class="title">Our Location</h2>
											</div>
	                					<div class="module-content">
	                	

<div class="custom"  >
	<div>
<p class="address">ULTRAVISION 6818 HEUERMANN ROAD SAN ANTONIO, TEXAS 78256</p>
<span class="text-icon email">ultra@lasik2c.com </span><br /> <span class="text-icon phone"> (210) 308-5550</span></div></div>
						<div class="clear"></div>
					</div>
				</div>
				            </div>
        	                    <div class="rt-block">
            	<div class="module-surround">
										<div class="module-content">
	                	<script type="text/javascript">window.addEvent('domready', function(){var config = {mapType				:'roadmap',width					:'auto',height					:'183',cavas_id				:"cavas_id177", zoom					:13,zoomControl			:true,scaleControl			:true,panControl				:true,mapTypeControl			:true,streetViewControl		:true,overviewMapControl		:true,draggable		:true,disableDoubleClickZoom		:false,scrollwheel		:true,weather				:0,temperatureUnit		:'f',cloud					:1,mapCenterType			:"address",mapCenterAddress		:"6818 Heuermann Road San Antonio, TX 78256",mapCenterCoordinate	:"40.7143528, -74.0059731",enableStyle			:"0",styleTitle				:"BT Map",createNewOrDefault		:"createNew",enableCustomInfoBox	:"0",boxPosition			:"-150,-155",closeBoxMargin			:"-9px",closeBoxImage			:"",url:"http://lasik2c.com/"};var boxStyles = {"background":"#ffffff","opacity":" 0.85","width":" 280px","height":"100px","border":" 1px solid grey","borderRadius":"3px","padding":" 10px","boxShadow":"30px 10px 10px 1px grey"};var markersCode ="W3sibWFya2VyVGl0bGUiOiJVbHRyYXZpc2nDs24gTGFzaWsgU2FuIEFudG9uaW8iLCJtYXJrZXJUeXBlIjoiYWRkcmVzcyIsIm1hcmtlclZhbHVlIjoiNjgxOCBIZXVlcm1hbm4gUm9hZCBTYW4gQW50b25pbywgVFggNzgyNTYiLCJtYXJrZXJJY29uIjoiIiwibWFya2VyU2hhZG93SW1hZ2UiOiIiLCJtYXJrZXJTaG93SW5mb1dpbmRvdyI6IjEiLCJtYXJrZXJJbmZvV2luZG93IjoiIn1d"; var stylesCode ="W10="; initializeMap(config, markersCode, stylesCode, boxStyles);});</script><div id="cavas_id177" class="bt-googlemaps"></div>
						<div class="clear"></div>
					</div>
				</div>
				            </div>
        	
</div>
<div class="rt-grid-4 rt-omega">
                        <div class="rt-block">
            	<div class="module-surround">
										<div class="module-title">
												<h2 class="title">Newsletter</h2>
											</div>
	                					<div class="module-content">
	                	<div class="acymailing_module" id="acymailing_module_formAcymailing18301">
	<div class="acymailing_fulldiv" id="acymailing_fulldiv_formAcymailing18301"  >
		<form id="formAcymailing18301" action="/" onsubmit="return submitacymailingform('optin','formAcymailing18301')" method="post" name="formAcymailing18301"  >
		<div class="acymailing_module_form" >
									<div class="acymailing_form">
					<p class="onefield" id="field_name_formAcymailing18301">								<span class="acyfield_name"><input id="user_name_formAcymailing18301"  onfocus="if(this.value == 'Name') this.value = '';" onblur="if(this.value=='') this.value='Name';" class="inputbox" type="text" name="user[name]" style="width:97%" value="Name" /></span>
							</p><p class="onefield" id="field_email_formAcymailing18301">								<span class="acyfield_email"><input id="user_email_formAcymailing18301"  onfocus="if(this.value == 'E-mail') this.value = '';" onblur="if(this.value=='') this.value='E-mail';" class="inputbox" type="text" name="user[email]" style="width:97%" value="E-mail" /></span>
							</p>
					<p class="acysubbuttons">
												<input class="button subbutton btn btn-primary" type="submit" value="Subscribe" name="Submit" onclick="try{ return submitacymailingform('optin','formAcymailing18301'); }catch(err){alert('The form could not be submitted '+err);return false;}"/>
											</p>
				</div>
						<input type="hidden" name="ajax" value="1"/>
			<input type="hidden" name="ctrl" value="sub"/>
			<input type="hidden" name="task" value="notask"/>
			<input type="hidden" name="redirect" value="http%3A%2F%2Flasik2c.com%2Findex.php"/>
			<input type="hidden" name="redirectunsub" value="http%3A%2F%2Flasik2c.com%2Findex.php"/>
			<input type="hidden" name="option" value="com_acymailing"/>
						<input type="hidden" name="hiddenlists" value="1"/>
			<input type="hidden" name="acyformname" value="formAcymailing18301" />
									</div>
		</form>
	</div>
	</div>
						<div class="clear"></div>
					</div>
				</div>
				            </div>
        	                <div class=" social">
                    <div class="rt-block">
            	<div class="module-surround">
										<div class="module-title">
												<h2 class="title">Get Touch With Us</h2>
											</div>
	                					<div class="module-content">
	                	

<div class="custom social"  >
	<p><a href="http://www.facebook.com/pages/Ultra-Vision-Dr-Tomy-Starck/115198815160069" target="_blank"> <img src="/images/social/1.png" alt="" /> </a> <a href="https://plus.google.com/112034885059419800019/about?hl=en" target="_blank"> <img src="/images/social/2.png" alt="" /> </a> <a href="http://twitter.com/ultravisionsatx" target="_blank"> <img src="/images/social/3.png" alt="" /> </a> <a href="http://www.youtube.com/user/UltraVisionSATX?feature=watch" target="_blank"> <img src="/images/social/4.png" alt="" /> </a></p></div>
						<div class="clear"></div>
					</div>
				</div>
				            </div>
                </div>
			
</div>
						<div class="clear"></div>
					</div>
				</div></div>
												<div id="rt-copyright"><div id="rt-copyright2">
					<div class="rt-container">
						<div class="rt-grid-4 rt-prefix-4 rt-alpha rt-omega">
    	    <div class="rt-block totop-block">
			<a href="#" id="gantry-totop"><span class="totop-desc"></span></a>
		</div>
		
</div>
						<div class="clear"></div>
					</div>
				</div></div>
							</div></div></div>
									<div id="rt-debug">
				<div class="rt-container">
					<div class="rt-grid-12 rt-alpha rt-omega">
                        <div class="rt-block">
            	<div class="module-surround">
										<div class="module-content">
	                	

<div class="custom"  >
	<div><a href="/index.php/en/testimonials">Testimonials Videos</a> | <a href="#">Own Style</a> | <a href="/index.php/lasik/am-i-a-candidate">Candidate</a> | <a href="/index.php/en/faq">FAQ</a> <span class="pull-right">Copyright © 2015 <a href="http://lasik2c.com/">lasik2c.com</a></span></div></div>
						<div class="clear"></div>
					</div>
				</div>
				            </div>
        	
</div>
					<div class="clear"></div>
				</div>
			</div>
											</div>
        <script>
           /* $(document).ready(function() {
                 
            $("#content_scroller").owlCarousel({
                
                navigation : true, // Show next and prev buttons
                slideSpeed : 300,
                paginationSpeed : 400,
                singleItem:true
                 
            });
             
            });*/
        </script>
	</body>
</html>
